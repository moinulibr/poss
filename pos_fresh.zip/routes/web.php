<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('clear', function() {
    $exitCode = Artisan::call('config:clear');
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('config:cache');
    $exitCode = Artisan::call('storage:link');
    return 'DONE'; //Return anything
});
Route::get('/', 'Landing\LandingController@index')->name('landing');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/home/test', 'HomeController@test')->name('test');






#,'routeCheck'
Route::group(['middleware' => ['auth']], function ()
{

    /*
    |----------------------------------------
    |   prodct attribute : Unit  middleware(['permissions:unit|index','auth_only:auth|yes'])
    |---------------------------------------
    */
        Route::group(['as'=> 'admin.', 'prefix'=>'admin','namespace'=>'Backend\ProductAttribute'],function(){
            Route::get('unit/list','UnitController@index')->name('unit.list')->middleware(['permissions:unit|index']);
        });

    /*
    |---------------------------
    | Employee
    |--------------------------
    */
        /* Route::group(['as'=> 'admin.', 'prefix'=>'admin' , 'namespace' => 'Backend\Admin\AllUser\Employee'],function(){
            Route::resource('employee', 'EmployeeController');
            Route::get('employee-print/{id}', 'EmployeeController@printAll')->name('employee.print');
            Route::get('employee-view-details', 'EmployeeController@viewDetails')->name('employee.viewDetails');
        }); */


});//end auth middleware


