<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<?php if(session('errors')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('errors')); ?>

</div>
<?php endif; ?>
<?php /**PATH E:\xampp\htdocs\pos\resources\views/layouts/backend/partial/success_error_status_message.blade.php ENDPATH**/ ?>