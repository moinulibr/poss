<?php

namespace App\Models\Backend\Product;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
}
