<?php

namespace App\Models\Backend\ProductAttribute;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    protected $table = 'brands';
    //protected $primaryKey = 'GROUP_ROLE_ID';
    protected $fillable = [
        'name','description','note','verified','deleted_at','verified_by','created_by'
    ];
}
