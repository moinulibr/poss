<?php

namespace App\Models\Backend\ProductAttribute;

use Illuminate\Database\Eloquent\Model;

class Color extends Model
{
    protected $table = 'colors';
    //protected $primaryKey = 'GROUP_ROLE_ID';
    protected $fillable = [
        'name','description','note','verified','deleted_at','verified_by','created_by'
    ];
}
