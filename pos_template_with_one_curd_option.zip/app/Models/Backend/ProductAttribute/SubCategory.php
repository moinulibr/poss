<?php

namespace App\Models\Backend\ProductAttribute;

use Illuminate\Database\Eloquent\Model;

class SubCategory extends Model
{
    protected $table = 'sub_categories';
    //protected $primaryKey = 'GROUP_ROLE_ID';
    protected $fillable = [
        'category_id','name','description','note','verified','deleted_at','verified_by','created_by'
    ];
}
