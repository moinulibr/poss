<?php

namespace App\Http\Controllers\Backend\ProductAttribute;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Backend\ProductAttribute\UnitRequest;
use Illuminate\Support\Facades\Auth;
//use Illuminate\Support\Facades\Validator;
use App\Models\Backend\ProductAttribute\Unit;

use App\Http\Requests\Backend\ProductAttribute\UnitValidationTrait;
use App\Traits\Backend\ProductAttribute\Unit\UnitTrait;
use App\Traits\Permission\Permission;

class UnitController extends Controller
{
    use Permission;
    use UnitTrait, UnitValidationTrait;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['datas'] = Unit::latest()->paginate(50);
        //return $this->callTraitForTest();
        return view('backend.product-attribute.unit.index',$data);
    }

    /**
     * Undocumented function
     *
     * @param Request $request
     * @return void
     */
    public function unitListByAjaxResponse(Request $request)
    {
        $data['datas'] = Unit::latest()->paginate(50);
        if($request->ajax())
        {
            $html = view('backend.product-attribute.unit.ajax.unit_list_ar',$data)->render();
            return response()->json([
                'status' => true,
                'html' => $html
            ]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        /* $this->unitId = 0;
        $unit = $this->getUnitByUnitId();
        if($unit['status'] == true){
           return $unit['unit']->full_name;
        }else{
            return "nai";
        } */
        $data['datas'] = Unit::latest()->get();
        return view('backend.product-attribute.unit.create',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $validators = $this->unitValidationWhenStoreUnit($request->all());
        if($validators['status'] == true)
        {
            return response()->json([
                'status' => 'errors',
                'error'=> $validators['errors']->getMessageBag()->toArray()
            ]);
        }
      
        $saveData =  auth()->user()->unitUsers()->create($request->all());

        $this->unitId = $request->parent_id;
        $unit = $this->getUnitByUnitId();
        $calculationResult = $request->calculation_value;
        if($unit['status'] == true){
            $calculationResult =  $unit['unit']->calculation_result * $request->calculation_value;
        }
        $saveData->calculation_result = $calculationResult;

        $this->unitId = $request->base_unit_id;
        $unit = $this->getUnitByUnitId();
        $baseUnitId = $request->base_unit_id;
        if($unit['status'] == true){
            $baseUnitId =  $unit['unit']->id;
        }
        $saveData->created_by = Auth::user()->id;
        $saveData->base_unit_id = $request->base_unit_id == 0 ? $saveData->id : $baseUnitId;
        $saveData->save();
        return response()->json([
            'status' => true,
            'type' => 'success',
            'message' => "Unit added successfully"
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Backend\ProductAttribute\Unit  $unit
     * @return \Illuminate\Http\Response
     */
    public function show(Unit $unit)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Backend\ProductAttribute\Unit  $unit
     * @return \Illuminate\Http\Response
     */
    public function edit(Unit $unit)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Backend\ProductAttribute\Unit  $unit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Unit $unit)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Backend\ProductAttribute\Unit  $unit
     * @return \Illuminate\Http\Response
     */
    public function destroy(Unit $unit)
    {
        //
    }
}
