$(function() {
  if ($('html').attr('dir') === 'rtl') {
    $('#nav-light-demo .dropdown-menu').addClass('dropdown-menu-right');
    $('#nav-dropdowns-demo .dropdown-menu').addClass('dropdown-menu-right');
  }
});
