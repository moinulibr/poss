<!DOCTYPE html>
<html lang="en" class="default-style layout-fixed layout-navbar-fixed">
    <!-- Mirrored from html.phoenixcoded.net/empire/bootstrap/default/tables_bootstrap.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 21 Jun 2020 10:58:42 GMT -->
    <head>
        <title> <?php echo e(config('app.name')); ?> <?php echo $__env->yieldContent('page_title'); ?></title>
        <meta charset="utf-8">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
        <meta name="description" content="Empire is one of the unique admin template built on top of Bootstrap 4 framework. It is easy to customize, flexible code styles, well tested, modern & responsive are the topmost key factors of Empire Dashboard Template" />
        <meta name="keywords" content="bootstrap admin template, dashboard template, backend panel, bootstrap 4, backend template, dashboard template, saas admin, CRM dashboard, eCommerce dashboard">
        <meta name="author" content="Codedthemes" />
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('backend/links/assets')); ?>/img/favicon.ico">

        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/fontawesome.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/ionicons.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/linearicons.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/open-iconic.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/pe-icon-7-stroke.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/feather.css">

        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/css/bootstrap-material.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/css/shreerang-material.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/css/uikit.css">

        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/libs/perfect-scrollbar/perfect-scrollbar.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/libs/flot/flot.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/libs/flot/flot.css">

       

        <link rel="stylesheet" href="<?php echo e(asset('custom_css/backend/for-all-file')); ?>/page-title-style.css">
        <?php echo $__env->yieldPushContent('extra-css'); ?>
        <?php echo $__env->yieldPushContent('custom-css'); ?>
        <?php echo $__env->yieldPushContent('css'); ?>
    </head>
    <body>
        <div class="page-loader">
            <div class="bg-primary"></div>
        </div>

        <!---layout-wrapper layout-2-->
        <div class="layout-wrapper layout-2">
            <!---layout-inner-->
            <div class="layout-inner">
                
                <!---------layout-sidenav-------->
                <div id="layout-sidenav" class="layout-sidenav sidenav sidenav-vertical bg-white logo-dark">
                    <!---left-sidenav-->
                    <?php echo $__env->make('layouts.backend.partial.left_side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!---left-sidenav-->
                    <div class="sidenav-divider mt-0"></div>
                </div><!---layout-sidenav-->
                <!---------layout-sidenav-------->

                <!---layout-container-->
                <div class="layout-container">
                    
                    <!---top header right side-->
                    <?php echo $__env->make('layouts.backend.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!---top header right side-->

                        <!---page_title_of_content-->
                        <?php echo $__env->yieldPushContent('page_title_of_content'); ?>
                        <!---page_title_of_content-->

                    <!---layout-content-->
                    <div class="layout-content">
                        <!---layout-content-->

                        
                        <!---container-fluid flex-grow-1 container-p-y-->
                        <div class="container-fluid flex-grow-1 container-p-y">
                            <!---container-fluid flex-grow-1 container-p-y--> 

                                <?php echo $__env->yieldContent('content'); ?>
                                
                            <!---container-fluid flex-grow-1 container-p-y-->    
                        </div><!---container-fluid flex-grow-1 container-p-y-->
                        <!---container-fluid flex-grow-1 container-p-y-->

                        <!---footer-->
                        <?php echo $__env->make('layouts.backend.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!---footer-->

                    </div><!---layout-content-->
                    <!---layout-content-->

                </div><!---layout-container-->
                <!---layout-container-->

            </div><!---layout-inner-->
            <!---layout-inner-->

            <div class="layout-overlay layout-sidenav-toggle"></div>
        </div><!---layout-wrapper layout-2-->
        <!---layout-wrapper layout-2-->


        <!-- AJAX Js-->
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/main.jquery-3.3.1.min.js"></script>

        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/pace.js"></script>
        
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/popper/popper.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/bootstrap.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/sidenav.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/layout-helpers.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/material-ripple.js"></script>

        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/eve/eve.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/flot/flot.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/flot/curvedLines.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/chart-am4/core.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/chart-am4/charts.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/chart-am4/animated.js"></script>

        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/demo.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/analytics.js"></script>

       
            

        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/pages/dashboards_index.js"></script>

           

        

        <!--notify js-->
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/notify.js"></script>

        <!-- select 2-->
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/select2.full.min.js"></script>
        <script>
            $('.select2').select2();
        </script>
        
        

        <!-- AJAX Js-->
        <script src="<?php echo e(asset('backend/links')); ?>/assets/js/pages/ui_modals.js"></script>
        <script>
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
        </script>

        <?php echo $__env->yieldPushContent('extra-js'); ?>
        <?php echo $__env->yieldPushContent('custom-js'); ?>
        <?php echo $__env->yieldPushContent('js'); ?>

    </body>

    <!-- Mirrored from html.phoenixcoded.net/empire/bootstrap/default/tables_bootstrap.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 21 Jun 2020 10:58:42 GMT -->
</html>
<?php /**PATH E:\xampp\htdocs\pos\resources\views/layouts/backend/app.blade.php ENDPATH**/ ?>