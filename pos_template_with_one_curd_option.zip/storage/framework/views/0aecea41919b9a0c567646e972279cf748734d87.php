

            <!-------form------> 
            
            <!-------form------> 

            <div class="modal-dialog modal-lg">
                <form action="<?php echo e(route('admin.unit.store')); ?>" method="POST" class="storeUnitData modal-content">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">
                            Unit 
                            <span class="font-weight-light">Information</span>
                            <br />
                            
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group row">
                            <div class="col-md-12 processing" style="text-align: center;display: none;">
                                <span style="color:saddlebrown;">
                                    <span class="spinner-border spinner-border-sm" role="status"></span>Processing
                                </span>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label class="col-form-label col-sm-3 text-sm-right">Unit Full Name</label>
                            <div class="col-sm-8">
                                <input name="full_name" type="text" class="form-control" placeholder="Unit Full Name">
                                <strong class="full_name_err color-red"></strong>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-sm-3 text-sm-right">Unit Short Name</label>
                            <div class="col-sm-8">
                                <input name="short_name" type="text" class="form-control" placeholder="Unit Short Name">
                                <strong class="short_name_err color-red"></strong>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-sm-3 text-sm-right">
                                    Parent Unit Name
                            </label>
                            <div class="col-sm-8">
                                <select name="parent_id" id="" class="form-control" style="background-color: lavender;color:green;">
                                    <option value="0">No Parent Unit</option>
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->full_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <strong class="parent_id_err color-red"></strong>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-sm-3 text-sm-right">
                                    Calculation Value
                            </label>
                            <div class="col-sm-8">
                                <input name="calculation_value" type="number" step="any" class="form-control" placeholder="Calculation By This Value"  style="background-color: lavender;color:green;">
                                <strong class="calculation_value_err color-red"></strong>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-sm-3 text-sm-right">Base Unit</label>
                            <div class="col-sm-8">
                                <select name="base_unit_id" id="" class="form-control">
                                    <option value="0">No Base Unit</option>
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->full_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <strong class="base_unit_id_err color-red"></strong>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-sm-3 text-sm-right">Description</label>
                            <div class="col-sm-8">
                                <textarea name="description" class="form-control" placeholder="Description"></textarea>
                                <strong class="description_err color-red"></strong>
                                <div class="clearfix"></div>
                            </div>
                        </div>

                        

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" role="status" value="Save">
                    </div>
                </form>
            </div>





<?php /**PATH E:\xampp\htdocs\pos\resources\views/backend/product-attribute/unit/create.blade.php ENDPATH**/ ?>