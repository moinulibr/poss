        <!-----left side bar top section - with logo---->
        <div class="app-brand demo">
            <span class="app-brand-logo demo">
            <img src="<?php echo e(asset('backend/links/assets')); ?>/img/logo.png" alt="Brand Logo" class="img-fluid">
            </span>
            <a href="<?php echo e(route('home')); ?>" class="app-brand-text demo sidenav-text font-weight-normal ml-2">Empire</a>
            <a href="javascript:" class="layout-sidenav-toggle sidenav-link text-large ml-auto">
            <i class="ion ion-md-menu align-middle"></i>
            </a>
        </div>
        <div class="sidenav-divider mt-0"></div>
        <!-----left side bar top section - with logo---->

         <!---left-sidenav-bottom-->
        <ul class="sidenav-inner py-1">

            <!---sales--->
            <li class="sidenav-item "> 
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Sales</div>
                    <div class="pl-1 ml-auto">
                        
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>Sale List</div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Sale Create</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Quotation List</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Sale Return</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---sales--->

            <!---purchase--->
            <li class="sidenav-item">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Purchase</div>
                    <div class="pl-1 ml-auto">
                        
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item">
                        <a href="index.html" class="sidenav-link">
                            <div>Purchase List</div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Purchase Create</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Purchase Return</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Quotation List</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Quotation Create</div>
                        <div class="pl-1 ml-auto">
                            <div class="badge badge-danger">New</div>
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Bypass Purchase</div>
                        <div class="pl-1 ml-auto">
                            <div class="badge badge-danger">New</div>
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Pending Receive</div>
                        <div class="pl-1 ml-auto">
                            <div class="badge badge-danger">New</div>
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Low Alert Product</div>
                        <div class="pl-1 ml-auto">
                            <div class="badge badge-danger">New</div>
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---purchase--->

            <!---Supplier--->
            <li class="sidenav-item">
                <a href="typography.html" class="sidenav-link">
                <i class="sidenav-icon feather icon-type"></i>
                <div>Supplier</div>
                </a>
            </li>
            <!---Supplier--->

            <!---Customers--->
            <li class="sidenav-item ">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Customers</div>
                    <div class="pl-1 ml-auto">
                        
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>Customer List</div>
                        </a>
                    </li> 
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>Walking Customer List</div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Customer Create</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Customer Bill Receive</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Customer Advance</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Customer Loan</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>SMS</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>SMS Group</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---Customer--->

            <!---products--->
            <li class="sidenav-item">
                <a href="typography.html" class="sidenav-link">
                <i class="sidenav-icon feather icon-type"></i>
                <div>Products</div>
                </a>
            </li>
            <!---products--->

            <!---Attendance--->
            <li class="sidenav-item  ">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Attendance</div>
                    <div class="pl-1 ml-auto">
                        
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>Add Attendance </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Attendance List</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Report</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---Attendance--->

            <!---Expense--->
            <li class="sidenav-item  ">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Expense</div>
                    <div class="pl-1 ml-auto">
                        
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>All Expense</div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Categories</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Plumber</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---Expense--->

            <!---Stock--->
            <li class="sidenav-item">
                <a href="typography.html" class="sidenav-link">
                <i class="sidenav-icon feather icon-type"></i>
                <div>Stock</div>
                </a>
            </li>
            <!---Stock--->

            <!---Account--->
            <li class="sidenav-item  ">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Account</div>
                    <div class="pl-1 ml-auto">
                        
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>Dino</div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Deposit</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Withdraw</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Transfer</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Accounts</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>ACC Closing</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Banks</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Loan Manager</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Payment Method</div>
                        <div class="pl-1 ml-auto">
                           
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Initial Assets</div>
                        <div class="pl-1 ml-auto">
                           
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Initial Assets</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Assets</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Blance Sheet</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---Account--->

            <!---Prouct Attribute--->
            <li class="sidenav-item  <?php echo e(url('admin/unit/*') ?'open active' : ''); ?>">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Prouct Attribute</div>
                    <div class="pl-1 ml-auto">
                       
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>Group </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Brands</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Categories</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item <?php echo e(url('admin/unit/*') ?'active' : ''); ?> ">
                        <a href="<?php echo e(route('admin.unit.index')); ?>" class="sidenav-link">
                        <div>Units</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Color</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---Prouct Attribute--->

            <!---HRM--->
            <li class="sidenav-item ">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>HRM</div>
                    <div class="pl-1 ml-auto">
                        
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>Manage User </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>User Salry</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Manage Role</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---HRM--->

            <!---Reports--->
            <li class="sidenav-item  ">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Reports</div>
                    <div class="pl-1 ml-auto">
                        
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>Sales (Today)</div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Daily Report</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Damange</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Invoice Sale</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Profit Loss Report</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Supplier Ledger</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---Reports--->

            <!---Delete--->
            <li class="sidenav-item">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Delete</div>
                    <div class="pl-1 ml-auto">
                        
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>User</div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Customer</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Supplier</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Cash Flow</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Sales</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="dashboards_corona.html" class="sidenav-link">
                        <div>Purchase</div>
                        <div class="pl-1 ml-auto">
                            
                        </div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---Delete--->
            
            <!---Setting--->
            <li class="sidenav-item  ">
                <a href="javascript:" class="sidenav-link sidenav-toggle">
                    <i class="sidenav-icon feather icon-home"></i>
                    <div>Setting</div>
                    <div class="pl-1 ml-auto">
                        <div class="badge badge-danger"></div>
                    </div>
                </a>
                <ul class="sidenav-menu">
                    <li class="sidenav-item ">
                        <a href="index.html" class="sidenav-link">
                            <div>User</div>
                        </a>
                    </li>
                </ul>
            </li>
            <!---Setting--->
        </ul> 
         <!---left-sidenav-bottom-->


        
        
<?php /**PATH E:\xampp\htdocs\pos\resources\views/layouts/backend/partial/left_side_bar.blade.php ENDPATH**/ ?>