<!DOCTYPE html>
<html lang="en" class="default-style layout-fixed layout-navbar-fixed">

    
    <head>
        <title>Empire | B4+ admin template</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
        <meta name="description" content="Empire is one of the unique admin template built on top of Bootstrap 4 framework. It is easy to customize, flexible code styles, well tested, modern & responsive are the topmost key factors of Empire Dashboard Template" />
        <meta name="keywords" content="bootstrap admin template, dashboard template, backend panel, bootstrap 4, backend template, dashboard template, saas admin, CRM dashboard, eCommerce dashboard">
        <meta name="author" content="Codedthemes" />
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('backend/links/assets')); ?>/img/favicon.ico">

        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/fontawesome.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/ionicons.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/linearicons.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/open-iconic.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/pe-icon-7-stroke.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/fonts/feather.css">

        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/css/bootstrap-material.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/css/shreerang-material.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/css/uikit.css">

        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/libs/perfect-scrollbar/perfect-scrollbar.css">
        <link rel="stylesheet" href="<?php echo e(asset('backend/links/assets')); ?>/libs/flot/flot.css">
    </head>
    <body>

        <div class="page-loader">
            <div class="bg-primary"></div>
        </div>


        <div class="layout-wrapper layout-2">
            <div class="layout-inner">

                <div id="layout-sidenav" class="layout-sidenav sidenav sidenav-vertical bg-white logo-dark">
                    <div class="app-brand demo">
                        <span class="app-brand-logo demo">
                        <img src="<?php echo e(asset('backend/links/assets')); ?>/img/logo.png" alt="Brand Logo" class="img-fluid">
                        </span>
                        <a href="index.html" class="app-brand-text demo sidenav-text font-weight-normal ml-2">Empire</a>
                        <a href="javascript:" class="layout-sidenav-toggle sidenav-link text-large ml-auto">
                        <i class="ion ion-md-menu align-middle"></i>
                        </a>
                    </div>
                    <div class="sidenav-divider mt-0"></div>

                    <ul class="sidenav-inner py-1">

                        <li class="sidenav-item open active">
                            <a href="javascript:" class="sidenav-link sidenav-toggle">
                                <i class="sidenav-icon feather icon-home"></i>
                                <div>Dashboards</div>
                                <div class="pl-1 ml-auto">
                                    <div class="badge badge-danger">Hot</div>
                                </div>
                            </a>
                            <ul class="sidenav-menu">
                                <li class="sidenav-item active">
                                    <a href="index.html" class="sidenav-link">
                                        <div>Default</div>
                                    </a>
                                </li>
                                <li class="sidenav-item">
                                    <a href="dashboards_corona.html" class="sidenav-link">
                                    <div>Corona</div>
                                    <div class="pl-1 ml-auto">
                                        <div class="badge badge-danger">New</div>
                                    </div>
                                </a>
                                </li>
                                <li class="sidenav-item">
                                    <a href="dashboards_ecommerce.html" class="sidenav-link">
                                        <div>Ecommerce</div>
                                    </a>
                                </li>
                                <li class="sidenav-item">
                                    <a href="dashboards_analytics.html" class="sidenav-link">
                                        <div>Analytics</div>
                                    </a>
                                </li>
                                <li class="sidenav-item">
                                    <a href="dashboards_crypto.html" class="sidenav-link">
                                        <div>Crypto</div>
                                    </a>
                                </li>
                                <li class="sidenav-item">
                                    <a href="dashboards_project.html" class="sidenav-link">
                                        <div>Project</div>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-layers"></i>
                        <div>Widgets</div>
                        <div class="pl-1 ml-auto">
                        <div class="badge badge-primary">100+</div>
                        </div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="w-simple.html" class="sidenav-link">
                        <div>Simple</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="w-data.html" class="sidenav-link">
                        <div>Data</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="w-social.html" class="sidenav-link">
                        <div>Social</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="w-chart.html" class="sidenav-link">
                        <div>Chart</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-layout"></i>
                        <div>Layouts</div>
                        <div class="pl-1 ml-auto">
                        <div class="badge badge-success">new</div>
                        </div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="layouts_sidenav_dark.html" class="sidenav-link" target="_blank">
                        <div>Navbar dark</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="layouts_header_dark.html" class="sidenav-link" target="_blank">
                        <div>Header dark</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="layouts_light.html" class="sidenav-link" target="_blank">
                        <div>Light layout</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="layouts_horizontal.html" class="sidenav-link" target="_blank">
                        <div>Horizontal</div>
                        </a>
                        </li>
                        </ul>
                        </li>

                        <li class="sidenav-divider mb-1"></li>
                        <li class="sidenav-header small font-weight-semibold">Admin Panels</li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-activity"></i>
                        <div>Hospital</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item"><a href="hospital-dashboard.html" class="sidenav-link">
                        <div>Dashboard</div>
                        </a></li>
                        <li class="sidenav-item"><a href="hospital-department.html" class="sidenav-link">
                        <div>Department</div>
                        </a></li>
                        <li class="sidenav-item"><a href="hospital-doctor.html" class="sidenav-link">
                        <div>Doctor</div>
                        </a></li>
                        <li class="sidenav-item"><a href="hospital-patient.html" class="sidenav-link">
                        <div>Patient</div>
                        </a></li>
                        <li class="sidenav-item"><a href="hospital-nurse.html" class="sidenav-link">
                        <div>Nurse</div>
                        </a></li>
                        <li class="sidenav-item"><a href="hospital-pharmacist.html" class="sidenav-link">
                        <div>Pharmacist</div>
                        </a></li>
                        <li class="sidenav-item"><a href="hospital-laboratorie.html" class="sidenav-link">
                        <div>Laboratory</div>
                        </a></li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-user-check"></i>
                        <div>Membership</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item"><a href="member-dashboard.html" class="sidenav-link">
                        <div>Dashboard</div>
                        </a></li>
                        <li class="sidenav-item"><a href="member-mail-template.html" class="sidenav-link">
                        <div>Email templates</div>
                        </a></li>
                        <li class="sidenav-item"><a href="member-countries.html" class="sidenav-link">
                        <div>Country</div>
                        </a></li>
                        <li class="sidenav-item"><a href="member-coupons.html" class="sidenav-link">
                        <div>Coupons</div>
                        </a></li>
                        <li class="sidenav-item"><a href="member-newsletter.html" class="sidenav-link">
                        <div>Newsletter</div>
                        </a></li>
                        <li class="sidenav-item"><a href="member-user.html" class="sidenav-link">
                        <div>User</div>
                        </a></li>
                        <li class="sidenav-item"><a href="member-membership.html" class="sidenav-link">
                        <div>Membership</div>
                        </a></li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-life-buoy"></i>
                        <div>Helpdesk</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item"><a href="help-dashboard.html" class="sidenav-link">
                        <div>Helpdesk dashboard</div>
                        </a></li>
                        <li class="sidenav-item"><a href="help-create-ticket.html" class="sidenav-link">
                        <div>Create ticket</div>
                        </a></li>
                        <li class="sidenav-item"><a href="help-ticket.html" class="sidenav-link">
                        <div>ticket list</div>
                        </a></li>
                        <li class="sidenav-item"><a href="help-ticket-details.html" class="sidenav-link">
                        <div>ticket Details</div>
                        </a></li>
                        <li class="sidenav-item"><a href="help-customer.html" class="sidenav-link">
                        <div>Customer</div>
                        </a></li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-book"></i>
                        <div>School</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item"><a href="school-dashboard.html" class="sidenav-link">
                        <div>Dashboard</div>
                        </a></li>
                        <li class="sidenav-item"><a href="school-student.html" class="sidenav-link">
                        <div>Student</div>
                        </a></li>
                        <li class="sidenav-item"><a href="school-parents.html" class="sidenav-link">
                        <div>Parents</div>
                        </a></li>
                        <li class="sidenav-item"><a href="school-teacher.html" class="sidenav-link">
                        <div>Teacher</div>
                        </a></li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle" data-toggle="tooltip" title="Student Information System">
                        <i class="sidenav-icon feather icon-book"></i>
                        <div>SIS</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item"><a href="sis-dashboard.html" class="sidenav-link">
                        <div>Dashboard</div>
                        </a></li>
                        <li class="sidenav-item"><a href="sis-leave.html" class="sidenav-link">
                        <div>Leave</div>
                        </a></li>
                        <li class="sidenav-item"><a href="sis-evaluation.html" class="sidenav-link">
                        <div>Evaluation</div>
                        </a></li>
                        <li class="sidenav-item"><a href="sis-event.html" class="sidenav-link">
                        <div>Event</div>
                        </a></li>
                        <li class="sidenav-item"><a href="sis-circular.html" class="sidenav-link">
                        <div>Circular</div>
                        </a></li>
                        <li class="sidenav-item"><a href="sis-course.html" class="sidenav-link">
                        <div>Course</div>
                        </a></li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-target"></i>
                        <div>Crypto</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item"><a href="crypto-dashboard.html" class="sidenav-link">
                        <div>Dashboard</div>
                        </a></li>
                        <li class="sidenav-item"><a href="crypto-exchange.html" class="sidenav-link">
                        <div>Exchange</div>
                        </a></li>
                        <li class="sidenav-item"><a href="crypto-wallet.html" class="sidenav-link">
                        <div>Wallet</div>
                        </a></li>
                        <li class="sidenav-item"><a href="crypto-transactions.html" class="sidenav-link">
                        <div>Transactions</div>
                        </a></li>
                        <li class="sidenav-item"><a href="crypto-history.html" class="sidenav-link">
                        <div>History</div>
                        </a></li>
                        <li class="sidenav-item"><a href="crypto-trading.html" class="sidenav-link">
                        <div>Trading</div>
                        </a></li>
                        <li class="sidenav-item"><a href="crypto-initial-coin.html" class="sidenav-link">
                        <div>Initial coin</div>
                        </a></li>
                        <li class="sidenav-item"><a href="crypto-ico-listing.html" class="sidenav-link">
                        <div>Ico listing</div>
                        </a></li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-shopping-cart"></i>
                        <div>E-Commerce</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item"><a href="ecom-product.html" class="sidenav-link">
                        <div>Product</div>
                        </a></li>
                        <li class="sidenav-item"><a href="ecom-product-details.html" class="sidenav-link">
                        <div>Product details</div>
                        </a></li>
                        <li class="sidenav-item"><a href="ecom-order.html" class="sidenav-link">
                        <div>Order</div>
                        </a></li>
                        <li class="sidenav-item"><a href="ecom-checkout.html" class="sidenav-link">
                        <div>Checkout</div>
                        </a></li>
                        <li class="sidenav-item"><a href="ecom-cart.html" class="sidenav-link">
                        <div>Shopping Cart</div>
                        </a></li>
                        <li class="sidenav-item"><a href="ecom-customers.html" class="sidenav-link">
                        <div>Customers</div>
                        </a></li>
                        <li class="sidenav-item"><a href="ecom-sellers.html" class="sidenav-link">
                        <div>Sellers</div>
                        </a></li>
                        </ul>
                        </li>

                        <li class="sidenav-divider mb-1"></li>
                        <li class="sidenav-header small font-weight-semibold">UI Components</li>
                        <li class="sidenav-item">
                        <a href="typography.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-type"></i>
                        <div>Typography</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-box"></i>
                        <div>Basic UI</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="bui_alert.html" class="sidenav-link">
                        <div>Alerts</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_accordion.html" class="sidenav-link">
                        <div>Accordion</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_badges.html" class="sidenav-link">
                        <div>Badges</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_button.html" class="sidenav-link">
                        <div>Buttons</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_button-groups.html" class="sidenav-link">
                        <div>Button groups</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_cards.html" class="sidenav-link">
                        <div>Cards</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_dropdowns.html" class="sidenav-link">
                        <div>Dropdowns</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_modals.html" class="sidenav-link">
                        <div>Modals</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_navs.html" class="sidenav-link">
                        <div>Navs [ Tabs ]</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_pagination.html" class="sidenav-link">
                        <div>Pagination and breadcrumbs</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_progress.html" class="sidenav-link">
                        <div>Progress bars</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_tooltips.html" class="sidenav-link">
                        <div>Tooltips and popovers</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="bui_thumbnails.html" class="sidenav-link">
                        <div>Thumbnails</div>
                        </a>
                        </li>
                        </ul>
                        </li>

                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-award"></i>
                        <div>Advanced UI</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="aui_carousel.html" class="sidenav-link">
                        <div>Carousel</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="aui_cropper.html" class="sidenav-link">
                        <div>Cropper.js</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="aui_drag-and-drop.html" class="sidenav-link">
                        <div>Drag&amp;Drop</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="aui_fullcalendar.html" class="sidenav-link">
                        <div>Fullcalendar</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="aui_kanban-board.html" class="sidenav-link">
                        <div>Kanban board</div>
                        <div class="pl-1 ml-auto">
                        <div class="badge badge-success">New</div>
                        </div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="aui_ladda.html" class="sidenav-link">
                        <div>Ladda</div>
                        <div class="pl-1 ml-auto">
                        <div class="badge badge-danger">Hot</div>
                        </div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="aui_lightbox.html" class="sidenav-link">
                        <div>Lightbox</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="aui_media-player.html" class="sidenav-link">
                        <div>Media player</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="aui_notifications.html" class="sidenav-link">
                        <div>Notifications</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="aui_todo-list.html" class="sidenav-link">
                        <div>Todo list</div>
                        </a>
                        </li>
                        </ul>
                        </li>

                        <li class="sidenav-divider mb-1"></li>
                        <li class="sidenav-header small font-weight-semibold">Forms & Tables</li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-clipboard"></i>
                        <div>Forms</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="forms_layouts.html" class="sidenav-link">
                        <div>Layouts and elements</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_controls.html" class="sidenav-link">
                        <div>Controls</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_custom-controls.html" class="sidenav-link">
                        <div>Custom controls</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_input-groups.html" class="sidenav-link">
                        <div>Input groups</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_switchers.html" class="sidenav-link">
                        <div>Switchers</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_sliders.html" class="sidenav-link">
                        <div>Sliders</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_selects.html" class="sidenav-link">
                        <div>Selects and tags</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_pickers.html" class="sidenav-link">
                        <div>Pickers</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_editors.html" class="sidenav-link">
                        <div>Editors</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_file-upload.html" class="sidenav-link">
                        <div>File upload</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_validation.html" class="sidenav-link">
                        <div>jQuery Validation</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_wizard.html" class="sidenav-link">
                        <div>SmartWizard</div>
                        <div class="pl-1 ml-auto">
                        <div class="badge badge-danger">Hot</div>
                        </div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_typeahead.html" class="sidenav-link">
                        <div>Typeahead</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_dual-listbox.html" class="sidenav-link">
                        <div>Bootstrap Dual Listbox</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="forms_extras.html" class="sidenav-link">
                        <div>Extras</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-grid"></i>
                        <div>Tables</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="tables_bootstrap.html" class="sidenav-link">
                        <div>Bootstrap</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="tables_datatables.html" class="sidenav-link">
                        <div>DataTables</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="tables_footables.html" class="sidenav-link">
                        <div>fooTables</div>
                        <div class="pl-1 ml-auto">
                        <div class="badge badge-danger">NEW</div>
                        </div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="tables_bootstrap-table.html" class="sidenav-link">
                        <div>Bootstrap table</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="tables_bootstrap-sortable.html" class="sidenav-link">
                        <div>Bootstrap Sortable</div>
                        </a>
                        </li>
                        </ul>
                        </li>

                        <li class="sidenav-divider mb-1"></li>
                        <li class="sidenav-header small font-weight-semibold">Chrt & Maps</li>
                        <li class="sidenav-item">
                        <a href="charts_gmaps.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-map-pin"></i>
                        <div>GMaps</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-pie-chart"></i>
                        <div>Charts</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="charts_am.html" class="sidenav-link">
                        <div>AM</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="charts_flot.html" class="sidenav-link">
                        <div>Flot.js</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="charts_chartist.html" class="sidenav-link">
                        <div>Chartist</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="charts_chartjs.html" class="sidenav-link">
                        <div>Chart.js</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="charts_morrisjs.html" class="sidenav-link">
                        <div>Morris.js</div>
                        </a>
                        </li>
                        </ul>
                        </li>

                        <li class="sidenav-divider mb-1"></li>
                        <li class="sidenav-header small font-weight-semibold">Icons</li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-feather"></i>
                        <div>Icons</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="icons_feather.html" class="sidenav-link">
                        <div>Feather</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="icons_font-awesome.html" class="sidenav-link">
                        <div>Font Awesome 5</div>
                        <div class="pl-1 ml-auto">
                        <div class="badge badge-primary">New</div>
                        </div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="icons_ionicons.html" class="sidenav-link">
                        <div>Ionicons</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="icons_linearicons.html" class="sidenav-link">
                        <div>Linearicons</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="icons_openiconic.html" class="sidenav-link">
                        <div>Open Iconic</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="icons_stroke7.html" class="sidenav-link">
                        <div>Stroke Icons 7</div>
                        </a>
                        </li>
                        </ul>
                        </li>

                        <li class="sidenav-divider mb-1"></li>
                        <li class="sidenav-header small font-weight-semibold">Pages</li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-lock"></i>
                        <div>Authentication</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <div>Login</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="pages_authentication_login-v1.html" class="sidenav-link">
                        <div>Login v1</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_authentication_login-v2.html" class="sidenav-link">
                        <div>Login v2</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_authentication_login-v3.html" class="sidenav-link">
                        <div>Login v3</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <div>Signup</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="pages_authentication_register-v1.html" class="sidenav-link">
                        <div>Register v1</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_authentication_register-v2.html" class="sidenav-link">
                        <div>Register v2</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_authentication_register-v3.html" class="sidenav-link">
                        <div>Register v3</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_authentication_login-and-register.html" class="sidenav-link">
                        <div>Login + Register</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_authentication_lock-screen-v1.html" class="sidenav-link">
                        <div>Lock screen v1</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_authentication_lock-screen-v2.html" class="sidenav-link">
                        <div>Lock screen v2</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_authentication_password-reset.html" class="sidenav-link">
                        <div>Password reset</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_authentication_email-confirm.html" class="sidenav-link">
                        <div>Email confirm</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-book"></i>
                        <div>Education</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="pages_education_courses-v1.html" class="sidenav-link">
                        <div>Courses v1</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_education_courses-v2.html" class="sidenav-link">
                        <div>Courses v2</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-shopping-cart"></i>
                        <div>E-commerce</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="pages_e-commerce_product-list.html" class="sidenav-link">
                        <div>Product list</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_e-commerce_product-item.html" class="sidenav-link">
                        <div>Product item</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_e-commerce_product-edit.html" class="sidenav-link">
                        <div>Product edit</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_e-commerce_order-list.html" class="sidenav-link">
                        <div>Order list</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_e-commerce_order-detail.html" class="sidenav-link">
                        <div>Order detail</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-mail"></i>
                        <div>Email</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="pages_messages_v3_list.html" class="sidenav-link">
                        <div>List</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_messages_v3_item.html" class="sidenav-link">
                        <div>Item</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_messages_v3_compose.html" class="sidenav-link">
                        <div>Compose</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-codepen"></i>
                        <div>Projects</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="pages_projects_list.html" class="sidenav-link">
                        <div>List</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_projects_item.html" class="sidenav-link">
                        <div>Item</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_teams.html" class="sidenav-link">
                        <div>Teams</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-shield"></i>
                        <div>Tickets</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="pages_tickets_list.html" class="sidenav-link">
                        <div>List</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_tickets_edit.html" class="sidenav-link">
                        <div>Edit</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="javascript:" class="sidenav-link sidenav-toggle">
                        <i class="sidenav-icon feather icon-users"></i>
                        <div>Users</div>
                        </a>
                        <ul class="sidenav-menu">
                        <li class="sidenav-item">
                        <a href="pages_users_list.html" class="sidenav-link">
                        <div>List</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_users_view.html" class="sidenav-link">
                        <div>View</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_profile-v1.html" class="sidenav-link">
                        <div>Profile v1</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_profile-v2.html" class="sidenav-link">
                        <div>Profile v2</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_users_edit.html" class="sidenav-link">
                        <div>Edit</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_account-settings.html" class="sidenav-link">
                        <div>Account settings</div>
                        </a>
                        </li>
                        </ul>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_chat.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-message-square"></i>
                        <div>Chat</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_faq.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-anchor"></i>
                        <div>FAQ</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_gallery.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-image"></i>
                        <div>Gallery</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_help-center.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-help-circle"></i>
                        <div>Help center</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_invoice.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-printer"></i>
                        <div>Invoice</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_search-results.html" class="sidenav-link">
                        <i class="sidenav-icon feather feather icon-filter"></i>
                        <div>Search results</div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_voting.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-thumbs-up"></i>
                        <div>Voting</div>
                        <div class="pl-1 ml-auto"><div class="badge badge-success">new</div></div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_pricing.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-tag"></i>
                        <div>Pricing</div>
                        <div class="pl-1 ml-auto"><div class="badge badge-success">new</div></div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_file-manger.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-folder"></i>
                        <div>file manager</div>
                        <div class="pl-1 ml-auto"><div class="badge badge-success">new</div></div>
                        </a>
                        </li>
                        <li class="sidenav-item">
                        <a href="pages_clients.html" class="sidenav-link">
                        <i class="sidenav-icon feather icon-users"></i>
                        <div>Clients</div>
                        <div class="pl-1 ml-auto"><div class="badge badge-success">new</div></div>
                        </a>
                        </li>
                    </ul>
                </div>
                <div class="layout-container">

                <nav class="layout-navbar navbar navbar-expand-lg align-items-lg-center bg-dark container-p-x" id="layout-navbar">

                <a href="index.html" class="navbar-brand app-brand demo d-lg-none py-0 mr-4">
                <span class="app-brand-logo demo">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/logo-dark.png" alt="Brand Logo" class="img-fluid">
                </span>
                <span class="app-brand-text demo font-weight-normal ml-2">Empire</span>
                </a>

                <div class="layout-sidenav-toggle navbar-nav d-lg-none align-items-lg-center mr-auto">
                <a class="nav-item nav-link px-0 mr-lg-4" href="javascript:">
                <i class="ion ion-md-menu text-large align-middle"></i>
                </a>
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#layout-navbar-collapse">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="navbar-collapse collapse" id="layout-navbar-collapse">

                <hr class="d-lg-none w-100 my-2">
                <div class="navbar-nav align-items-lg-center">
                    <label class="nav-item navbar-text navbar-search-box p-0 active">
                    <i class="feather icon-search navbar-icon align-middle"></i>
                    <span class="navbar-search-input pl-2">
                    <input type="text" class="form-control navbar-text mx-2" placeholder="Search...">
                    </span>
                    </label>
                </div>
                <div class="navbar-nav align-items-lg-center ml-auto">
                <div class="demo-navbar-notifications nav-item dropdown mr-lg-3">
                    <a class="nav-link dropdown-toggle hide-arrow" href="#" data-toggle="dropdown">
                    <i class="feather icon-bell navbar-icon align-middle"></i>
                    <span class="badge badge-danger badge-dot indicator"></span>
                    <span class="d-lg-none align-middle">&nbsp; Notifications</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                    <div class="bg-primary text-center text-white font-weight-bold p-3">
                    4 New Notifications
                    </div>
                    <div class="list-group list-group-flush">
                    <a href="javascript:" class="list-group-item list-group-item-action media d-flex align-items-center">
                    <div class="ui-icon ui-icon-sm feather icon-home bg-secondary border-0 text-white"></div>
                    <div class="media-body line-height-condenced ml-3">
                    <div class="text-dark">Login from 192.168.1.1</div>
                    <div class="text-light small mt-1">
                    Aliquam ex eros, imperdiet vulputate hendrerit et.
                    </div>
                    <div class="text-light small mt-1">12h ago</div>
                    </div>
                    </a>
                    <a href="javascript:" class="list-group-item list-group-item-action media d-flex align-items-center">
                    <div class="ui-icon ui-icon-sm feather icon-user-plus bg-primary border-0 text-white"></div>
                    <div class="media-body line-height-condenced ml-3">
                    <div class="text-dark">You have
                    <strong>4</strong> new followers</div>
                    <div class="text-light small mt-1">
                    Phasellus nunc nisl, posuere cursus pretium nec, dictum vehicula tellus.
                    </div>
                    </div>
                    </a>
                    <a href="javascript:" class="list-group-item list-group-item-action media d-flex align-items-center">
                    <div class="ui-icon ui-icon-sm feather icon-power bg-danger border-0 text-white"></div>
                    <div class="media-body line-height-condenced ml-3">
                        <div class="text-dark">Server restarted</div>
                        <div class="text-light small mt-1">
                            19h ago
                        </div>
                    </div>
                    </a>
                    <a href="javascript:" class="list-group-item list-group-item-action media d-flex align-items-center">
                    <div class="ui-icon ui-icon-sm feather icon-alert-triangle bg-warning border-0 text-dark"></div>
                    <div class="media-body line-height-condenced ml-3">
                    <div class="text-dark">99% server load</div>
                    <div class="text-light small mt-1">
                    Etiam nec fringilla magna. Donec mi metus.
                    </div>
                    <div class="text-light small mt-1">
                    20h ago
                    </div>
                    </div>
                    </a>
                    </div>
                    <a href="javascript:" class="d-block text-center text-light small p-2 my-1">Show all notifications</a>
                    </div>
                </div>
                <div class="demo-navbar-messages nav-item dropdown mr-lg-3">
                    <a class="nav-link dropdown-toggle hide-arrow" href="#" data-toggle="dropdown">
                        <i class="feather icon-mail navbar-icon align-middle"></i>
                        <span class="badge badge-success badge-dot indicator"></span>
                        <span class="d-lg-none align-middle">&nbsp; Messages</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                        <div class="bg-primary text-center text-white font-weight-bold p-3">
                        4 New Messages
                        </div>
                        <div class="list-group list-group-flush">
                        <a href="javascript:" class="list-group-item list-group-item-action media d-flex align-items-center">
                        <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/6-small.png" class="d-block ui-w-40 rounded-circle" alt>
                        <div class="media-body ml-3">
                        <div class="text-dark line-height-condenced">Lorem ipsum dolor consectetuer elit.</div>
                        <div class="text-light small mt-1">
                        Josephin Doe &nbsp;·&nbsp; 58m ago
                        </div>
                        </div>
                    </a>
                    <a href="javascript:" class="list-group-item list-group-item-action media d-flex align-items-center">
                    <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/4-small.png" class="d-block ui-w-40 rounded-circle" alt>
                    <div class="media-body ml-3">
                    <div class="text-dark line-height-condenced">Lorem ipsum dolor sit amet, consectetuer.</div>
                    <div class="text-light small mt-1">
                    Lary Doe &nbsp;·&nbsp; 1h ago
                    </div>
                    </div>
                    </a>
                    <a href="javascript:" class="list-group-item list-group-item-action media d-flex align-items-center">
                    <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/5-small.png" class="d-block ui-w-40 rounded-circle" alt>
                    <div class="media-body ml-3">
                    <div class="text-dark line-height-condenced">Lorem ipsum dolor sit amet elit.</div>
                    <div class="text-light small mt-1">
                    Alice &nbsp;·&nbsp; 2h ago
                    </div>
                    </div>
                    </a>
                    <a href="javascript:" class="list-group-item list-group-item-action media d-flex align-items-center">
                    <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/11-small.png" class="d-block ui-w-40 rounded-circle" alt>
                    <div class="media-body ml-3">
                    <div class="text-dark line-height-condenced">Lorem ipsum dolor sit amet consectetuer amet elit dolor sit.</div>
                    <div class="text-light small mt-1">
                    Suzen &nbsp;·&nbsp; 5h ago
                    </div>
                    </div>
                    </a>
                    </div>
                    <a href="javascript:" class="d-block text-center text-light small p-2 my-1">Show all messages</a>
                    </div>
                </div>

                <div class="nav-item d-none d-lg-block text-big font-weight-light line-height-1 opacity-25 mr-3 ml-1">|</div>
                    <div class="demo-navbar-user nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">
                        <span class="d-inline-flex flex-lg-row-reverse align-items-center align-middle">
                        <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/1.png" alt class="d-block ui-w-30 rounded-circle">
                        <span class="px-1 mr-lg-2 ml-2 ml-lg-0">Cindy Deitch</span>
                        </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a href="javascript:" class="dropdown-item">
                            <i class="feather icon-user text-muted"></i> &nbsp; My profile</a>
                            <a href="javascript:" class="dropdown-item">
                            <i class="feather icon-mail text-muted"></i> &nbsp; Messages</a>
                            <a href="javascript:" class="dropdown-item">
                            <i class="feather icon-settings text-muted"></i> &nbsp; Account settings</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                            <i class="feather icon-power text-danger"></i> &nbsp; Log Out</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>
                </div>
                </nav>


                <div class="layout-content">

                <div class="container-fluid flex-grow-1 container-p-y">
                <h4 class="font-weight-bold py-3 mb-0">Dashboard</h4>
                <div class="text-muted small mt-0 mb-4 d-block breadcrumb">
                <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                <li class="breadcrumb-item active">Main</li>
                </ol>
                </div>
                <div class="row">

                <div class="col-lg-5">
                <div class="row">
                <div class="col-md-6">
                <div class="card mb-4">
                <div class="card-body">
                <div class="d-flex align-items-center justify-content-between">
                <div class="">
                <h2 class="mb-2"> 256 </h2>
                <p class="text-muted mb-0"><span class="badge badge-primary">Revenue</span> Today</p>
                </div>
                <div class="lnr lnr-leaf display-4 text-primary"></div>
                </div>
                </div>
                </div>
                </div>
                <div class="col-md-6">
                <div class="card mb-4">
                <div class="card-body">
                <div class="d-flex align-items-center justify-content-between">
                <div class="">
                <h2 class="mb-2">8451</h2>
                <p class="text-muted mb-0"><span class="badge badge-success">20%</span> Stock</p>
                </div>
                <div class="lnr lnr-chart-bars display-4 text-success"></div>
                </div>
                </div>
                </div>
                </div>
                <div class="col-md-6">
                <div class="card mb-4">
                <div class="card-body">
                <div class="d-flex align-items-center justify-content-between">
                <div class="">
                <h2 class="mb-2"> 31% <small></small></h2>
                <p class="text-muted mb-0">New <span class="badge badge-danger">20%</span> Customer</p>
                </div>
                <div class="lnr lnr-rocket display-4 text-danger"></div>
                </div>
                </div>
                </div>
                </div>
                <div class="col-md-6">
                <div class="card mb-4">
                <div class="card-body">
                <div class="d-flex align-items-center justify-content-between">
                <div class="">
                <h2 class="mb-2">158</h2>
                <p class="text-muted mb-0"><span class="badge badge-warning">$143.45</span> Profit</p>
                </div>
                <div class="lnr lnr-cart display-4 text-warning"></div>
                </div>
                </div>
                </div>
                </div>
                <div class="col-sm-12">
                <div class="card d-flex w-100 mb-4">
                <div class="row no-gutters row-bordered row-border-light h-100">
                <div class="d-flex col-md-6 align-items-center">
                <div class="card-body">
                <div class="row align-items-center mb-3">
                <div class="col-auto">
                <i class="lnr lnr-users text-primary display-4"></i>
                </div>
                <div class="col">
                <h6 class="mb-0 text-muted">Unique <span class="text-primary">Visitors</span></h6>
                <h4 class="mt-3 mb-0">652<i class="ion ion-md-arrow-round-down ml-3 text-danger"></i></h4>
                </div>
                </div>
                <p class="mb-0 text-muted">36% From Last 6 Months</p>
                </div>
                </div>
                <div class="d-flex col-md-6 align-items-center">
                <div class="card-body">
                <div class="row align-items-center mb-3">
                <div class="col-auto">
                <i class="lnr lnr-magic-wand text-primary display-4"></i>
                </div>
                <div class="col">
                <h6 class="mb-0 text-muted">Monthly <span class="text-primary">Earnings</span></h6>
                <h4 class="mt-3 mb-0">5963<i class="ion ion-md-arrow-round-up ml-3 text-success"></i></h4>
                </div>
                </div>
                <p class="mb-0 text-muted">36% From Last 6 Months</p>
                </div>
                </div>
                </div>
                </div>
                </div>
                </div>
                </div>
                <div class="col-lg-7">
                <div class="card mb-4">
                <div class="card-header with-elements">
                <h6 class="card-header-title mb-0">Statistics</h6>
                <div class="card-header-elements ml-auto">
                <label class="text m-0">
                <span class="text-light text-tiny font-weight-semibold align-middle">SHOW STATS</span>
                <span class="switcher switcher-primary switcher-sm d-inline-block align-middle mr-0 ml-2"><input type="checkbox" class="switcher-input" checked><span class="switcher-indicator"><span class="switcher-yes"></span><span class="switcher-no"></span></span></span>
                </label>
                </div>
                </div>
                <div class="card-body">
                <div id="statistics-chart-1" style="height:300px"></div>
                </div>
                </div>
                </div>

                </div>
                <div class="row">

                <div class="col-md-6">
                <div class="card d-flex w-100 mb-4">
                <div class="row no-gutters row-bordered row-border-light h-100">
                <div class="d-flex col-sm-6 col-md-4 col-lg-6 align-items-center">
                <div class="card-body media align-items-center text-dark">
                <i class="lnr lnr-diamond display-4 d-block text-primary"></i>
                <span class="media-body d-block ml-3"><span class="text-big mr-1 text-primary">$1584.78</span>
                <br>
                <small class="text-muted">Earned this month</small>
                </span>
                </div>
                </div>
                <div class="d-flex col-sm-6 col-md-4 col-lg-6 align-items-center">
                <div class="card-body media align-items-center text-dark">
                <i class="lnr lnr-clock display-4 d-block text-warning"></i>
                <span class="media-body d-block ml-3"><span class="text-big"><span class="mr-1 text-warning">152</span>Working Hours</span>
                <br>
                <small class="text-muted">Spent this month</small>
                </span>
                </div>
                </div>
                <div class="d-flex col-sm-6 col-md-4 col-lg-6 align-items-center">
                <div class="card-body media align-items-center text-dark">
                <i class="lnr lnr-hourglass display-4 d-block text-danger"></i>
                <span class="media-body d-block ml-3"><span class="text-big"><span class="mr-1 text-danger">54</span> Tasks</span>
                <br>
                <small class="text-muted">Completed this month</small>
                </span>
                </div>
                </div>
                <div class="d-flex col-sm-6 col-md-4 col-lg-6 align-items-center">
                <div class="card-body media align-items-center text-dark">
                <i class="lnr lnr-license display-4 d-block text-success"></i>
                <span class="media-body d-block ml-3"><span class="text-big"><span class="mr-1 text-success">6</span> Projects</span>
                <br>
                <small class="text-muted">Done this month</small>
                </span>
                </div>
                </div>
                </div>
                </div>
                </div>
                <div class="col-md-6">
                <div class="row">
                <div class="col-md-6">
                <div class="card mb-4 bg-pattern-3 bg-primary text-white">
                <div class="card-body">
                <div class="d-flex align-items-center">
                <div class="lnr lnr-cart display-4"></div>
                <div class="ml-3">
                <div class="small">Monthly sales</div>
                <div class="text-large">2362</div>
                </div>
                </div>
                <div id="order-chart-1" class="mt-3 chart-shadow" style="height:70px"></div>
                </div>
                </div>
                </div>
                <div class="col-md-6">
                <div class="card mb-4 bg-pattern-3-dark">
                <div class="card-body">
                <div class="d-flex align-items-center">
                <div class="lnr lnr-gift display-4 text-primary"></div>
                <div class="ml-3">
                <div class="text-muted small">Products</div>
                <div class="text-large">985</div>
                </div>
                </div>
                <div id="ecom-chart-3" class="mt-3 chart-shadow-primary" style="height:70px"></div>
                </div>
                </div>
                </div>
                </div>
                </div>

                </div>
                <div class="row">

                <div class="col-xl-5">
                <div class="card mb-4">
                <div class="card-header with-elements">
                <h6 class="card-header-title mb-0">Tasks</h6>
                <div class="card-header-elements ml-auto">
                <button type="button" class="btn btn-default btn-xs md-btn-flat">Show more</button>
                </div>
                </div>
                <div style="height: 310px" id="tasks-inner">
                <div class="card-body">
                <p class="text-muted small">Today</p>
                <div class="custom-controls-stacked">
                <label class="ui-todo-item custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label">Buy products</span>
                <span class="ui-todo-badge badge badge-outline-default font-weight-normal ml-2">58 mins left</span>
                </label>
                <label class="ui-todo-item custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label">Reply to emails</span>
                </label>
                <label class="ui-todo-item custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label">Write blog post</span>
                <span class="ui-todo-badge badge badge-outline-default font-weight-normal ml-2">20 hours left</span>
                </label>
                <label class="ui-todo-item custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" checked>
                <span class="custom-control-label">Wash my car</span>
                </label>
                </div>
                </div>
                <hr class="m-0">
                <div class="card-body">
                <p class="text-muted small">Tomorrow</p>
                <div class="custom-controls-stacked">
                <label class="ui-todo-item custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label">Buy antivirus</span>
                </label>
                <label class="ui-todo-item custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label">Janes Happy Birthday</span>
                </label>
                <label class="ui-todo-item custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label">Call mom</span>
                </label>
                </div>
                </div>
                </div>
                <div class="card-footer">
                <div class="input-group">
                <input type="text" class="form-control" placeholder="Type your task">
                <div class="input-group-append">
                <button type="button" class="btn btn-primary">Add</button>
                </div>
                </div>
                </div>
                </div>
                </div>
                <div class="col-xl-7">
                <div class="card mb-4">
                <div class="card-header with-elements pb-0">
                <h6 class="card-header-title mb-0">Customer details</h6>
                <div class="card-header-elements ml-auto p-0">
                <ul class="nav nav-tabs">
                <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#sale-stats">Sale stats</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#latest-sales">Latest sales</a>
                </li>
                </ul>
                </div>
                </div>
                <div class="nav-tabs-top">
                <div class="tab-content">
                <div class="tab-pane fade show active" id="sale-stats">
                <div style="height: 330px" id="tab-table-1">
                <table class="table table-hover card-table">
                <thead>
                <tr>
                <th>
                <label class="custom-control custom-checkbox mb-0">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label"><strong>Due</strong></span>
                </label>
                </th>
                <th>User</th>
                <th>Description</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                <td>
                <label class="custom-control custom-checkbox mb-0">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label"><strong>12</strong><br><span>hour</span></span>
                </label>
                </td>
                <td>
                <div class="media mb-0">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/3-small.png" class="d-block ui-w-40 rounded-circle" alt="">
                <div class="media-body align-self-center ml-3">
                <h6 class="mb-0">John Deo</h6>
                </div>
                </div>
                </td>
                <td>
                <div class="d-inline-block align-middle">
                <h6 class="mb-1">[#1183] Workaround for OS X selects printing bug</h6>
                <p class="text-muted mb-0">Chrome fixed the bug several versions ago, thus rendering this...</p>
                </div>
                </td>
                </tr>
                <tr>
                <td>
                <label class="custom-control custom-checkbox mb-0">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label"><strong>16</strong><br><span>hour</span></span>
                </label>
                </td>
                <td>
                <div class="media mb-0">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/1-small.png" class="d-block ui-w-40 rounded-circle" alt="">
                <div class="media-body align-self-center ml-3">
                <h6 class="mb-0">Jems Win</h6>
                </div>
                </div>
                </td>
                <td>
                <div class="d-inline-block align-middle">
                <h6 class="mb-1">[#1249] Vertically center carousel controls</h6>
                <p class="text-muted mb-0">Try any carousel control and reduce the screen width below...</p>
                </div>
                </td>
                </tr>
                <tr>
                <td>
                <label class="custom-control custom-checkbox mb-0">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label"><strong>40</strong><br><span>hour</span></span>
                </label>
                </td>
                <td>
                <div class="media mb-0">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/1-small.png" class="d-block ui-w-40 rounded-circle" alt="">
                <div class="media-body align-self-center ml-3">
                <h6 class="mb-0">Jems Wiliiam</h6>
                </div>
                </div>
                </td>
                <td>
                <div class="d-inline-block align-middle">
                <h6 class="mb-1">[#1254] Inaccurate small pagination height</h6>
                <p class="text-muted mb-0">The height of pagination elements is not consistent with...</p>
                </div>
                </td>
                </tr>
                <tr>
                <td>
                <label class="custom-control custom-checkbox mb-0">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label"><strong>12</strong><br><span>hour</span></span>
                </label>
                </td>
                <td>
                <div class="media mb-0">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/3-small.png" class="d-block ui-w-40 rounded-circle" alt="">
                <div class="media-body align-self-center ml-3">
                <h6 class="mb-0">John Deo</h6>
                </div>
                </div>
                </td>
                <td>
                <div class="d-inline-block align-middle">
                <h6 class="mb-1">[#1183] Workaround for OS X selects printing bug</h6>
                <p class="text-muted mb-0">Chrome fixed the bug several versions ago, thus rendering this...</p>
                </div>
                </td>
                </tr>
                <tr>
                <td>
                <label class="custom-control custom-checkbox mb-0">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label"><strong>12</strong><br><span>hour</span></span>
                </label>
                </td>
                <td>
                <div class="media mb-0">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/3-small.png" class="d-block ui-w-40 rounded-circle" alt="">
                <div class="media-body align-self-center ml-3">
                <h6 class="mb-0">John Deo</h6>
                </div>
                </div>
                </td>
                <td>
                <div class="d-inline-block align-middle">
                <h6 class="mb-1">[#1183] Workaround for OS X selects printing bug</h6>
                <p class="text-muted mb-0">Chrome fixed the bug several versions ago, thus rendering this...</p>
                </div>
                </td>
                </tr>
                <tr>
                <td>
                <label class="custom-control custom-checkbox mb-0">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label"><strong>16</strong><br><span>hour</span></span>
                </label>
                </td>
                <td>
                <div class="media mb-0">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/1-small.png" class="d-block ui-w-40 rounded-circle" alt="">
                <div class="media-body align-self-center ml-3">
                <h6 class="mb-0">Jems Win</h6>
                </div>
                </div>
                </td>
                <td>
                <div class="d-inline-block align-middle">
                <h6 class="mb-1">[#1249] Vertically center carousel controls</h6>
                <p class="text-muted mb-0">Try any carousel control and reduce the screen width below...</p>
                </div>
                </td>
                </tr>
                <tr>
                <td>
                <label class="custom-control custom-checkbox mb-0">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label"><strong>40</strong><br><span>hour</span></span>
                </label>
                </td>
                <td>
                <div class="media mb-0">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/1-small.png" class="d-block ui-w-40 rounded-circle" alt="">
                <div class="media-body align-self-center ml-3">
                <h6 class="mb-0">Jems Wiliiam</h6>
                </div>
                </div>
                </td>
                <td>
                <div class="d-inline-block align-middle">
                <h6 class="mb-1">[#1254] Inaccurate small pagination height</h6>
                <p class="text-muted mb-0">The height of pagination elements is not consistent with...</p>
                </div>
                </td>
                </tr>
                <tr>
                <td>
                <label class="custom-control custom-checkbox mb-0">
                <input type="checkbox" class="custom-control-input">
                <span class="custom-control-label"><strong>12</strong><br><span>hour</span></span>
                </label>
                </td>
                <td>
                <div class="media mb-0">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/avatars/3-small.png" class="d-block ui-w-40 rounded-circle" alt="">
                <div class="media-body align-self-center ml-3">
                <h6 class="mb-0">John Deo</h6>
                </div>
                </div>
                </td>
                <td>
                <div class="d-inline-block align-middle">
                <h6 class="mb-1">[#1183] Workaround for OS X selects printing bug</h6>
                <p class="text-muted mb-0">Chrome fixed the bug several versions ago, thus rendering this...</p>
                </div>
                </td>
                </tr>
                </tbody>
                </table>
                </div>
                <a href="javascript:" class="card-footer d-block text-center text-dark small font-weight-semibold">SHOW MORE</a>
                </div>
                <div class="tab-pane fade" id="latest-sales">
                <div style="height: 330px" id="tab-table-2">
                <table class="table table-hover card-table">
                <thead>
                <tr>
                <th>Product</th>
                <th>Qty.</th>
                <th>Sum.</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">PlayStation 4 1TB (Jet Black)</a>
                </td>
                <td class="align-middle">1</td>
                <td class="align-middle">$480.00</td>
                </tr>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">Nike Men Black Liteforce III Sneakers</a>
                </td>
                <td class="align-middle">2</td>
                <td class="align-middle">$115.1</td>
                </tr>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">Wireless headphones</a>
                </td>
                <td class="align-middle">1</td>
                <td class="align-middle">$235.55</td>
                </tr>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">HERO ATHLETES BAG</a>
                </td>
                <td class="align-middle">1</td>
                <td class="align-middle">$160.00</td>
                </tr>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">POÄNG</a>
                </td>
                <td class="align-middle">3</td>
                <td class="align-middle">$477.00</td>
                </tr>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">Apple iWatch (black)</a>
                </td>
                <td class="align-middle">1</td>
                <td class="align-middle">$399.00</td>
                </tr>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">WALKING 400 BLUE CAT3</a>
                </td>
                <td class="align-middle">2</td>
                <td class="align-middle">$41.1</td>
                </tr>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">Wireless headphones</a>
                </td>
                <td class="align-middle">1</td>
                <td class="align-middle">$235.55</td>
                </tr>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">HERO ATHLETES BAG</a>
                </td>
                <td class="align-middle">1</td>
                <td class="align-middle">$160.00</td>
                </tr>
                <tr>
                <td class="align-middle">
                <a href="javascript:" class="text-dark">POÄNG</a>
                </td>
                <td class="align-middle">3</td>
                <td class="align-middle">$477.00</td>
                </tr>
                </tbody>
                </table>
                </div>
                <a href="javascript:" class="card-footer d-block text-center text-dark small font-weight-semibold">SHOW MORE</a>
                </div>
                </div>
                </div>
                </div>
                </div>

                </div>
                </div>

                <!-----Footer Nav------>
                <!-----Footer Nav------>

                </div>

                </div>

            </div>

            <div class="layout-overlay layout-sidenav-toggle"></div>
        </div>


            <!-------------Modal------------>
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <div class="modal-content">
                <div class="modal-body pb-1">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                <div class="text-center">
                <h3 class="mt-3">Welcome To <span class="text-primary">Empire</span><sup>v1.0.1</sup></h3>
                </div>
                <div class="carousel-inner">
                <div class="carousel-item active" data-interval="50000">
                <div class="row align-items-center">
                <div class="col-md-6 text-center">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/pages/welcome.png" class="img-fluid my-4" alt="images">
                </div>
                <div class="col-md-6">
                <p class="f-16"><strong>Empire Admin v1.0.1</strong> will come with new prebuild mini admins.</p>
                <p class="f-16"> it include <strong>8+ New Admin Panels</strong> like</p>
                <p class="mb-2 f-16"><i class="feather icon-check-circle mr-2 text-primary"></i>Hospital</p>
                <p class="mb-2 f-16"><i class="feather icon-check-circle mr-2 text-primary"></i>Project & CRM</p>
                <p class="mb-2 f-16"><i class="feather icon-check-circle mr-2 text-primary"></i>Membership</p>
                <p class="mb-2 f-16"><i class="feather icon-check-circle mr-2 text-primary"></i>Helpdesk</p>
                <p class="mb-2 f-16"><i class="feather icon-check-circle mr-2 text-primary"></i>School</p>
                <p class="mb-2 f-16"><i class="feather icon-check-circle mr-2 text-primary"></i>SIS</p>
                <p class="mb-2 f-16"><i class="feather icon-check-circle mr-2 text-primary"></i>Crypto</p>
                <p class="mb-2 f-16"><i class="feather icon-check-circle mr-2 text-primary"></i>E-Commerce</p>
                </div>
                </div>
                <div class="row justify-content-center">
                <div class="col-lg-9">
                </div>
                </div>
                </div>
                <div class="carousel-item" data-interval="50000">
                <img src="<?php echo e(asset('backend/links/assets')); ?>/img/pages/admin.png" class="img-fluid mt-0" alt="images">
                </div>
                </div>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" style="transform:rotate(180deg);margin-bottom:-1px">
                <path class="elementor-shape-fill" fill="#2c3134" opacity="0.33" d="M473,67.3c-203.9,88.3-263.1-34-320.3,0C66,119.1,0,59.7,0,59.7V0h1000v59.7 c0,0-62.1,26.1-94.9,29.3c-32.8,3.3-62.8-12.3-75.8-22.1C806,49.6,745.3,8.7,694.9,4.7S492.4,59,473,67.3z">
                </path>
                <path class="elementor-shape-fill" fill="#2c3134" opacity="0.66" d="M734,67.3c-45.5,0-77.2-23.2-129.1-39.1c-28.6-8.7-150.3-10.1-254,39.1 s-91.7-34.4-149.2,0C115.7,118.3,0,39.8,0,39.8V0h1000v36.5c0,0-28.2-18.5-92.1-18.5C810.2,18.1,775.7,67.3,734,67.3z"></path>
                <path class="elementor-shape-fill" fill="#2c3134" d="M766.1,28.9c-200-57.5-266,65.5-395.1,19.5C242,1.8,242,5.4,184.8,20.6C128,35.8,132.3,44.9,89.9,52.5C28.6,63.7,0,0,0,0 h1000c0,0-9.9,40.9-83.6,48.1S829.6,47,766.1,28.9z">
                </path>
                </svg>
                <div class="modal-body text-center py-4" style="background:#2c3134">
                <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>

                </ol>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="ml-2">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="mr-2">Next</span>
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                </a>
                </div>
                </div>
                </div>
                </div>
            </div>
            <!-------------Modal------------>

        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/pace.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/jquery-3.3.1.min.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/popper/popper.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/bootstrap.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/sidenav.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/layout-helpers.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/material-ripple.js"></script>

        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/eve/eve.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/flot/flot.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/flot/curvedLines.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/chart-am4/core.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/chart-am4/charts.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/libs/chart-am4/animated.js"></script>

        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/demo.js"></script>
        <script src="<?php echo e(asset('backend/links/assets')); ?>/js/analytics.js"></script>
        <script>
                $(document).ready(function() {
                    // checkCookie();
                    $('#exampleModalCenter').modal();
                });

                function setCookie(cname, cvalue, exdays) {
                    var d = new Date();
                    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                    var expires = "expires=" + d.toGMTString();
                    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
                }

                function getCookie(cname) {
                    var name = cname + "=";
                    var decodedCookie = decodeURIComponent(document.cookie);
                    var ca = decodedCookie.split(';');
                    for (var i = 0; i < ca.length; i++) {
                        var c = ca[i];
                        while (c.charAt(0) == ' ') {
                            c = c.substring(1);
                        }
                        if (c.indexOf(name) == 0) {
                            return c.substring(name.length, c.length);
                        }
                    }
                    return "";
                }

                function checkCookie() {
                    var ticks = getCookie("modelopen");
                    if (ticks != "") {
                        ticks++;
                        setCookie("modelopen", ticks, 1);
                        if (ticks == "2" || ticks == "1" || ticks == "0") {
                            $('#exampleModalCenter').modal();
                        }
                    } else {
                        // user = prompt("Please enter your name:", "");
                        $('#exampleModalCenter').modal();
                        ticks = 1;
                        setCookie("modelopen", ticks, 1);
                    }
                }
            </script>
            <script src="<?php echo e(asset('backend/links/assets')); ?>/js/pages/dashboards_index.js"></script>
    </body>
    <!-- Mirrored from html.phoenixcoded.net/empire/bootstrap/default/index.html by HTTrack Website Copier/3.x [XR&CO2014], Sun, 21 Jun 2020 10:47:10 GMT -->
</html>








<?php /**PATH E:\Xampp\htdocs\Laravel\Softsecurity\softitsecurity\constraction\resources\views/layouts/app.blade.php ENDPATH**/ ?>