<div class="table-responsive">
    <table class="table table-bordered mb-0">
        <thead>
            <tr>
                <th>#</th>
                <th>Unit Full Name</th>
                <th>Short Name</th>
                <th>Parent Unit</th>
                <th>Base Unit</th>
                <th>Description</th>
                <th style="width:3%;">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">
                        <?php echo e($index + 1); ?>

                    </th>
                    <td>
                        <?php echo e($item->full_name); ?>

                    </td>
                    <td><?php echo e($item->short_name); ?></td>
                    <td>
                        <?php
                            $parent = $item->parentUnit(); 
                            $parentName = "No Parent";
                            if($parent['status'] == true)
                            {
                                $parentName = $parent['unit']->short_name;
                            } 
                        ?>
                        <?php echo e($parentName); ?>

                    </td>
                    <td>
                        <?php
                            $parent = $item->baseUnit(); 
                            $parentName = "No Base Unit";
                            if($parent['status'] == true)
                            {
                                $parentName = $parent['unit']->short_name;
                            } 
                        ?>
                        <?php echo e($parentName); ?>

                    </td>
                    <td>
                        <?php echo e($item->description); ?>

                    </td>
                    <td style="width:3%;">
                        <div class="btn-group btnGroupForMoreAction">
                            <button type="button" class="btn btn-sm" data-toggle="dropdown" aria-expanded="true">
                                <i class="fas fa-ellipsis-v"></i>
                                
                            </button>
                            <div class="dropdown-menu " x-placement="top-start" style="position: absolute; will-change: top, left; top: -183px; left: 0px;">
                            <a class="dropdown-item" href="javascript:void(0)">View</a>
                            <a class="dropdown-item" href="javascript:void(0)">Edit</a>
                            <a class="dropdown-item" href="javascript:void(0)">Delete</a>
                            
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($datas->links()); ?>

</div><?php /**PATH E:\xampp\htdocs\pos\resources\views/backend/product-attribute/unit/partial/list.blade.php ENDPATH**/ ?>